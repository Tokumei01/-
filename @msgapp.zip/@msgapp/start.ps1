clear
set-location "English"
start-process "English.exe"
exit